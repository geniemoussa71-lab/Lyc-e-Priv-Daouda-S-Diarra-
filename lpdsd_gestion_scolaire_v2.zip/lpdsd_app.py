from flask import Flask, request, redirect, url_for, session, render_template_string, flash, send_file
import sqlite3, os, io, hashlib
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

APP_DIR='/mnt/data/lpdsd_data'
os.makedirs(APP_DIR, exist_ok=True)
DB=os.path.join(APP_DIR,'lpdsd.db')
app=Flask(__name__); app.secret_key='LPDSD_CHANGE_THIS_SECRET'

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
    c=db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT DEFAULT 'admin');
    CREATE TABLE IF NOT EXISTS classes(id INTEGER PRIMARY KEY, name TEXT UNIQUE, level TEXT, school_year TEXT);
    CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY, matricule TEXT UNIQUE, first_name TEXT, last_name TEXT, sex TEXT, dob TEXT, phone TEXT, class_id INTEGER, guardian TEXT, guardian_phone TEXT, created_at TEXT, FOREIGN KEY(class_id) REFERENCES classes(id));
    CREATE TABLE IF NOT EXISTS teachers(id INTEGER PRIMARY KEY, matricule TEXT UNIQUE, first_name TEXT, last_name TEXT, phone TEXT, subject TEXT, class_name TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, student_id INTEGER, amount REAL, purpose TEXT, paid_at TEXT, reference TEXT, FOREIGN KEY(student_id) REFERENCES students(id));
    CREATE TABLE IF NOT EXISTS grades(id INTEGER PRIMARY KEY, student_id INTEGER, subject TEXT, term TEXT, score REAL, coefficient REAL DEFAULT 1, FOREIGN KEY(student_id) REFERENCES students(id));
    ''')
    if not c.execute('SELECT 1 FROM users WHERE username=?',('admin',)).fetchone():
        c.execute('INSERT INTO users(username,password,role) VALUES(?,?,?)',('admin',hashlib.sha256(b'admin123').hexdigest(),'admin'))
    if not c.execute('SELECT 1 FROM classes').fetchone():
        for x in [('7e', 'Collège','2026-2027'),('8e','Collège','2026-2027'),('9e','Collège','2026-2027'),('10e','Lycée','2026-2027'),('11e','Lycée','2026-2027'),('12e','Lycée','2026-2027')]: c.execute('INSERT OR IGNORE INTO classes(name,level,school_year) VALUES(?,?,?)',x)
    c.commit(); c.close()
init()

BASE='''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LPDSD Gestion Scolaire</title><style>
body{font-family:Arial;margin:0;background:#f4f6f8;color:#17202a}.nav{background:#123b5d;color:white;padding:15px 20px;display:flex;justify-content:space-between}.nav a{color:white;margin-left:15px;text-decoration:none}.wrap{max-width:1150px;margin:25px auto;padding:0 15px}.card{background:white;border-radius:12px;padding:20px;margin:15px 0;box-shadow:0 2px 10px #0001}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:15px}.stat{font-size:28px;font-weight:bold}.btn{display:inline-block;background:#1769aa;color:#fff;padding:9px 13px;border-radius:7px;text-decoration:none;border:0;cursor:pointer}.danger{background:#b42318}.input,select{padding:10px;width:100%;box-sizing:border-box;margin:5px 0 12px;border:1px solid #ccd3da;border-radius:6px}table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #e4e7eb;text-align:left}th{background:#eef3f7}.flash{padding:10px;background:#e6f4ea;margin:10px 0;border-radius:6px}@media(max-width:600px){.nav{display:block}.nav a{display:inline-block;margin:8px 8px 0 0}}
</style></head><body><div class="nav"><b>LPDSD — Gestion Scolaire</b><div>{% if session.get('user') %}<a href="{{url_for('dashboard')}}">Accueil</a><a href="{{url_for('students')}}">Élèves</a><a href="{{url_for('teachers')}}">Enseignants</a><a href="{{url_for('payments')}}">Paiements</a><a href="{{url_for('grades')}}">Notes</a><a href="{{url_for('logout')}}">Déconnexion</a>{% endif %}</div></div><div class="wrap">{% with msgs=get_flashed_messages() %}{% for m in msgs %}<div class="flash">{{m}}</div>{% endfor %}{% endwith %}{{body|safe}}</div></body></html>'''
def page(body,**ctx): return render_template_string(BASE,body=render_template_string(body,**ctx))
def login_required(): return bool(session.get('user'))

@app.route('/',methods=['GET','POST'])
def login():
    if session.get('user'): return redirect(url_for('dashboard'))
    if request.method=='POST':
        u=request.form['username']; p=hashlib.sha256(request.form['password'].encode()).hexdigest(); c=db(); row=c.execute('SELECT * FROM users WHERE username=? AND password=?',(u,p)).fetchone(); c.close()
        if row: session['user']=u; return redirect(url_for('dashboard'))
        flash('Identifiants incorrects.')
    return page('''<div class="card" style="max-width:420px;margin:70px auto"><h2>Connexion administrateur</h2><p>Le Lycée Privé Daouda S Diarra</p><form method="post"><label>Nom d'utilisateur</label><input class="input" name="username" value="admin"><label>Mot de passe</label><input class="input" name="password" type="password"><button class="btn">Se connecter</button></form><small>Première connexion : admin / admin123 — à changer avant utilisation réelle.</small></div>''')
@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if not login_required(): return redirect(url_for('login'))
    c=db(); stats=[c.execute('SELECT COUNT(*) n FROM students').fetchone()['n'],c.execute('SELECT COUNT(*) n FROM teachers').fetchone()['n'],c.execute('SELECT COUNT(*) n FROM classes').fetchone()['n'],c.execute('SELECT COALESCE(SUM(amount),0) n FROM payments').fetchone()['n']]; c.close()
    return page('''<h1>Tableau de bord</h1><div class="grid"><div class="card"><div class="stat">{{stats[0]}}</div>Élèves</div><div class="card"><div class="stat">{{stats[1]}}</div>Enseignants</div><div class="card"><div class="stat">{{stats[2]}}</div>Classes</div><div class="card"><div class="stat">{{'%.0f'|format(stats[3])}}</div>FCFA encaissés</div></div><div class="card"><h3>Modules</h3><a class="btn" href="{{url_for('students')}}">Gérer les élèves</a> <a class="btn" href="{{url_for('teachers')}}">Gérer les enseignants</a> <a class="btn" href="{{url_for('payments')}}">Paiements / reçus</a> <a class="btn" href="{{url_for('grades')}}">Notes / bulletins</a></div>''',stats=stats)

@app.route('/students',methods=['GET','POST'])
def students():
    if not login_required(): return redirect(url_for('login'))
    c=db()
    if request.method=='POST':
        try:
            c.execute('INSERT INTO students(matricule,first_name,last_name,sex,dob,phone,class_id,guardian,guardian_phone,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(request.form['matricule'],request.form['first_name'],request.form['last_name'],request.form['sex'],request.form['dob'],request.form['phone'],request.form['class_id'],request.form['guardian'],request.form['guardian_phone'],datetime.now().isoformat()))
            c.commit(); flash('Élève enregistré avec succès.')
        except Exception as e: flash('Erreur : '+str(e))
    rows=c.execute('SELECT s.*,c.name class_name FROM students s LEFT JOIN classes c ON c.id=s.class_id ORDER BY s.last_name,s.first_name').fetchall(); classes=c.execute('SELECT * FROM classes ORDER BY name').fetchall(); c.close()
    return page('''<h1>Élèves</h1><div class="card"><h3>Nouvelle inscription</h3><form method="post" class="grid"><input class="input" name="matricule" placeholder="Matricule" required><input class="input" name="first_name" placeholder="Prénom" required><input class="input" name="last_name" placeholder="Nom" required><select name="sex"><option>M</option><option>F</option></select><input class="input" name="dob" type="date"><input class="input" name="phone" placeholder="Téléphone"><select name="class_id">{% for c in classes %}<option value="{{c.id}}">{{c.name}}</option>{% endfor %}</select><input class="input" name="guardian" placeholder="Parent/Tuteur"><input class="input" name="guardian_phone" placeholder="Téléphone tuteur"><button class="btn">Enregistrer</button></form></div><div class="card"><table><tr><th>Matricule</th><th>Nom</th><th>Classe</th><th>Téléphone</th><th>Action</th></tr>{% for s in rows %}<tr><td>{{s.matricule}}</td><td>{{s.last_name}} {{s.first_name}}</td><td>{{s.class_name}}</td><td>{{s.phone}}</td><td><a class="btn" href="{{url_for('student_detail',sid=s.id)}}">Fiche</a></td></tr>{% endfor %}</table></div>''',rows=rows,classes=classes)

@app.route('/student/<int:sid>')
def student_detail(sid):
    if not login_required(): return redirect(url_for('login'))
    c=db(); s=c.execute('SELECT s.*,c.name class_name FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=?',(sid,)).fetchone(); pays=c.execute('SELECT * FROM payments WHERE student_id=? ORDER BY paid_at DESC',(sid,)).fetchall(); gr=c.execute('SELECT * FROM grades WHERE student_id=?',(sid,)).fetchall(); c.close()
    return page('''<h1>Fiche élève</h1><div class="card"><h2>{{s.last_name}} {{s.first_name}}</h2><p>Matricule : {{s.matricule}} | Classe : {{s.class_name}} | Tuteur : {{s.guardian}}</p><a class="btn" href="{{url_for('payment_new',sid=s.id)}}">Ajouter paiement</a> <a class="btn" href="{{url_for('bulletin',sid=s.id)}}">Bulletin PDF</a></div><div class="card"><h3>Paiements</h3><table><tr><th>Date</th><th>Montant</th><th>Motif</th><th>Reçu</th></tr>{% for p in pays %}<tr><td>{{p.paid_at}}</td><td>{{p.amount}} FCFA</td><td>{{p.purpose}}</td><td><a href="{{url_for('receipt',pid=p.id)}}">PDF</a></td></tr>{% endfor %}</table></div>''',s=s,pays=pays,gr=gr)

@app.route('/payment/new/<int:sid>',methods=['GET','POST'])
def payment_new(sid):
    if not login_required(): return redirect(url_for('login'))
    c=db(); s=c.execute('SELECT * FROM students WHERE id=?',(sid,)).fetchone()
    if request.method=='POST':
        ref='PAY-'+datetime.now().strftime('%Y%m%d%H%M%S'); c.execute('INSERT INTO payments(student_id,amount,purpose,paid_at,reference) VALUES(?,?,?,?,?)',(sid,float(request.form['amount']),request.form['purpose'],datetime.now().strftime('%Y-%m-%d %H:%M'),ref)); c.commit(); pid=c.execute('SELECT last_insert_rowid()').fetchone()[0]; c.close(); return redirect(url_for('receipt',pid=pid))
    c.close(); return page('''<div class="card"><h2>Paiement — {{s.last_name}} {{s.first_name}}</h2><form method="post"><input class="input" name="amount" type="number" step="1" placeholder="Montant FCFA" required><input class="input" name="purpose" placeholder="Motif (scolarité, inscription...)" required><button class="btn">Enregistrer et imprimer le reçu</button></form></div>''',s=s)

@app.route('/receipt/<int:pid>')
def receipt(pid):
    if not login_required(): return redirect(url_for('login'))
    c=db(); p=c.execute('SELECT p.*,s.first_name,s.last_name,s.matricule FROM payments p JOIN students s ON s.id=p.student_id WHERE p.id=?',(pid,)).fetchone(); c.close()
    buf=io.BytesIO(); doc=SimpleDocTemplate(buf,pagesize=A4); st=getSampleStyleSheet(); story=[Paragraph('<b>LE LYCEE PRIVE DAO​​UDA S DIARRA — LPDSD</b>',st['Title']),Spacer(1,20),Paragraph('REÇU DE PAIEMENT',st['Heading2']),Spacer(1,15),Paragraph(f"Référence : {p['reference']}<br/>Élève : {p['last_name']} {p['first_name']}<br/>Matricule : {p['matricule']}<br/>Motif : {p['purpose']}<br/>Montant : <b>{p['amount']:.0f} FCFA</b><br/>Date : {p['paid_at']}",st['BodyText']),Spacer(1,40),Paragraph('Signature et cachet de l’établissement',st['BodyText'])]; doc.build(story); buf.seek(0); return send_file(buf,as_attachment=False,download_name='recu.pdf',mimetype='application/pdf')

@app.route('/teachers',methods=['GET','POST'])
def teachers():
    if not login_required(): return redirect(url_for('login'))
    c=db()
    if request.method=='POST':
        c.execute('INSERT INTO teachers(matricule,first_name,last_name,phone,subject,class_name,created_at) VALUES(?,?,?,?,?,?,?)',(request.form['matricule'],request.form['first_name'],request.form['last_name'],request.form['phone'],request.form['subject'],request.form['class_name'],datetime.now().isoformat())); c.commit(); flash('Enseignant enregistré.')
    rows=c.execute('SELECT * FROM teachers ORDER BY last_name').fetchall(); c.close(); return page('''<h1>Enseignants</h1><div class="card"><form method="post" class="grid"><input class="input" name="matricule" placeholder="Matricule" required><input class="input" name="first_name" placeholder="Prénom" required><input class="input" name="last_name" placeholder="Nom" required><input class="input" name="phone" placeholder="Téléphone"><input class="input" name="subject" placeholder="Matière"><input class="input" name="class_name" placeholder="Classe"><button class="btn">Enregistrer</button></form></div><div class="card"><table><tr><th>Matricule</th><th>Nom</th><th>Matière</th><th>Classe</th><th>Téléphone</th></tr>{% for t in rows %}<tr><td>{{t.matricule}}</td><td>{{t.last_name}} {{t.first_name}}</td><td>{{t.subject}}</td><td>{{t.class_name}}</td><td>{{t.phone}}</td></tr>{% endfor %}</table></div>''',rows=rows)

@app.route('/payments')
def payments():
    if not login_required(): return redirect(url_for('login'))
    c=db(); rows=c.execute('SELECT p.*,s.first_name,s.last_name,s.matricule FROM payments p JOIN students s ON s.id=p.student_id ORDER BY p.id DESC').fetchall(); c.close(); return page('''<h1>Paiements</h1><div class="card"><table><tr><th>Référence</th><th>Élève</th><th>Montant</th><th>Motif</th><th>Date</th><th>Reçu</th></tr>{% for p in rows %}<tr><td>{{p.reference}}</td><td>{{p.last_name}} {{p.first_name}}</td><td>{{p.amount}} FCFA</td><td>{{p.purpose}}</td><td>{{p.paid_at}}</td><td><a href="{{url_for('receipt',pid=p.id)}}">PDF</a></td></tr>{% endfor %}</table></div>''',rows=rows)

@app.route('/grades',methods=['GET','POST'])
def grades():
    if not login_required(): return redirect(url_for('login'))
    c=db()
    if request.method=='POST': c.execute('INSERT INTO grades(student_id,subject,term,score,coefficient) VALUES(?,?,?,?,?)',(request.form['student_id'],request.form['subject'],request.form['term'],float(request.form['score']),float(request.form['coefficient']))); c.commit(); flash('Note enregistrée.')
    students=c.execute('SELECT * FROM students ORDER BY last_name').fetchall(); rows=c.execute('SELECT g.*,s.first_name,s.last_name FROM grades g JOIN students s ON s.id=g.student_id ORDER BY g.id DESC').fetchall(); c.close(); return page('''<h1>Notes</h1><div class="card"><form method="post" class="grid"><select name="student_id">{% for s in students %}<option value="{{s.id}}">{{s.last_name}} {{s.first_name}} — {{s.matricule}}</option>{% endfor %}</select><input class="input" name="subject" placeholder="Matière" required><select name="term"><option>Trimestre 1</option><option>Trimestre 2</option><option>Trimestre 3</option></select><input class="input" name="score" type="number" step="0.01" min="0" max="20" placeholder="Note /20" required><input class="input" name="coefficient" type="number" step="0.5" value="1"><button class="btn">Enregistrer</button></form></div><div class="card"><table><tr><th>Élève</th><th>Matière</th><th>Période</th><th>Note</th><th>Coef.</th></tr>{% for g in rows %}<tr><td>{{g.last_name}} {{g.first_name}}</td><td>{{g.subject}}</td><td>{{g.term}}</td><td>{{g.score}}</td><td>{{g.coefficient}}</td></tr>{% endfor %}</table></div>''',students=students,rows=rows)

@app.route('/bulletin/<int:sid>')
def bulletin(sid):
    if not login_required(): return redirect(url_for('login'))
    c=db(); s=c.execute('SELECT s.*,c.name class_name FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=?',(sid,)).fetchone(); gs=c.execute('SELECT subject,term,score,coefficient FROM grades WHERE student_id=? ORDER BY term,subject',(sid,)).fetchall(); c.close()
    buf=io.BytesIO(); doc=SimpleDocTemplate(buf,pagesize=A4); st=getSampleStyleSheet(); story=[Paragraph('LE LYCEE PRIVE DAO​​UDA S DIARRA — LPDSD',st['Title']),Paragraph('BULLETIN SCOLAIRE',st['Heading2']),Spacer(1,10),Paragraph(f"Élève : {s['last_name']} {s['first_name']}<br/>Matricule : {s['matricule']}<br/>Classe : {s['class_name']}",st['BodyText']),Spacer(1,15)]
    data=[['Matière','Période','Note /20','Coef.']]+[[g['subject'],g['term'],str(g['score']),str(g['coefficient'])] for g in gs]; t=Table(data,colWidths=[180,120,90,70]); t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#123b5d')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),.5,colors.grey),('PADDING',(0,0),(-1,-1),7)])); story += [t,Spacer(1,20),Paragraph('Observation / Décision du conseil de classe : ________________________________',st['BodyText']),Spacer(1,35),Paragraph('Le Proviseur',st['BodyText'])]; doc.build(story); buf.seek(0); return send_file(buf,as_attachment=False,download_name='bulletin.pdf',mimetype='application/pdf')

if __name__=='__main__': app.run(host='127.0.0.1',port=5000,debug=False)
