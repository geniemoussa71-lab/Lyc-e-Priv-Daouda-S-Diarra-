LPDSD — GESTION SCOLAIRE PROFESSIONNELLE

Lancement:
1. Installer Python 3.10+.
2. Ouvrir un terminal dans ce dossier.
3. pip install -r requirements.txt
4. python lpdsd_app.py
5. Ouvrir http://127.0.0.1:5000

Compte initial:
admin / admin123
Changez immédiatement le mot de passe via /users/password.

Rôles:
- Administrateur: accès complet, comptes et sauvegardes.
- Secrétaire: élèves et enseignants.
- Comptable: paiements et reçus.
- Enseignant: notes et bulletins.

Base: lpdsd_data/lpdsd.db
Les sauvegardes administrateur sont dans lpdsd_data/backups/.
Pour un déploiement Internet, utiliser HTTPS, une clé LPDSD_SECRET persistante, sauvegardes hors serveur et une politique de mots de passe forte.
