from flask import Flask, request, redirect, url_for, session, render_template_string, flash, send_file, abort
import sqlite3, os, io, secrets, shutil
from datetime import datetime
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

APP_DIR=os.path.join(os.path.dirname(__file__),'lpdsd_data')
os.makedirs(APP_DIR, exist_ok=True)
DB=os.path.join(APP_DIR,'lpdsd.db')
BACKUP_DIR=os.path.join(APP_DIR,'backups'); os.makedirs(BACKUP_DIR, exist_ok=True)
app=Flask(__name__); app.secret_key=os.environ.get('LPDSD_SECRET', secrets.token_hex(32))

ROLES={
 'admin': {'label':'Administrateur','perms':{'dashboard','students','teachers','payments','grades','users','backup'}},
 'secretary': {'label':'Secrétaire','perms':{'dashboard','students','teachers'}},
 'accountant': {'label':'Comptable','perms':{'dashboard','payments'}},
 'teacher': {'label':'Enseignant','perms':{'dashboard','grades'}}
}

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def init():
 c=db(); c.executescript('''
 CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL, full_name TEXT, active INTEGER DEFAULT 1, created_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS classes(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, level TEXT, school_year TEXT);
 CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY, matricule TEXT UNIQUE NOT NULL, first_name TEXT NOT NULL, last_name TEXT NOT NULL, sex TEXT, dob TEXT, phone TEXT, class_id INTEGER, guardian TEXT, guardian_phone TEXT, created_at TEXT NOT NULL, FOREIGN KEY(class_id) REFERENCES classes(id));
 CREATE TABLE IF NOT EXISTS teachers(id INTEGER PRIMARY KEY, matricule TEXT UNIQUE NOT NULL, first_name TEXT NOT NULL, last_name TEXT NOT NULL, phone TEXT, subject TEXT, class_name TEXT, created_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL, amount REAL NOT NULL, purpose TEXT NOT NULL, paid_at TEXT NOT NULL, reference TEXT UNIQUE NOT NULL, received_by INTEGER, FOREIGN KEY(student_id) REFERENCES students(id), FOREIGN KEY(received_by) REFERENCES users(id));
 CREATE TABLE IF NOT EXISTS grades(id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL, subject TEXT NOT NULL, term TEXT NOT NULL, score REAL NOT NULL, coefficient REAL DEFAULT 1, entered_by INTEGER, FOREIGN KEY(student_id) REFERENCES students(id), FOREIGN KEY(entered_by) REFERENCES users(id));
 CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
 ''')
 if not c.execute('SELECT 1 FROM users').fetchone():
  c.execute('INSERT INTO users(username,password_hash,role,full_name,created_at) VALUES(?,?,?,?,?)',('admin',generate_password_hash('admin123'),'admin','Administrateur',datetime.now().isoformat()))
 if not c.execute('SELECT 1 FROM classes').fetchone():
  for x in [('7e','Collège','2026-2027'),('8e','Collège','2026-2027'),('9e','Collège','2026-2027'),('10e','Lycée','2026-2027'),('11e','Lycée','2026-2027'),('12e','Lycée','2026-2027')]: c.execute('INSERT OR IGNORE INTO classes(name,level,school_year) VALUES(?,?,?)',x)
 c.commit(); c.close()
init()

def current_user():
 if not session.get('user_id'): return None
 c=db(); u=c.execute('SELECT * FROM users WHERE id=? AND active=1',(session['user_id'],)).fetchone(); c.close(); return u

def permission(name):
 def deco(f):
  @wraps(f)
  def wrapped(*a,**kw):
   u=current_user()
   if not u: return redirect(url_for('login'))
   if name not in ROLES.get(u['role'],{}).get('perms',set()): abort(403)
   return f(*a,**kw)
  return wrapped
 return deco

def log(action):
 u=current_user();
 if u:
  c=db(); c.execute('INSERT INTO audit_log(user_id,action,created_at) VALUES(?,?,?)',(u['id'],action,datetime.now().isoformat())); c.commit(); c.close()

BASE='''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LPDSD — Gestion Scolaire Pro</title><style>
:root{--nav:#0b3558;--accent:#1473a5;--bg:#f4f7fa;--card:#fff;--text:#17202a;--muted:#65727e;--line:#dce3e8}*{box-sizing:border-box}body{font-family:Inter,Arial,sans-serif;margin:0;background:var(--bg);color:var(--text)}.nav{background:var(--nav);color:#fff;padding:15px 20px;display:flex;justify-content:space-between;align-items:center;gap:15px}.nav a{color:#fff;margin-left:12px;text-decoration:none;font-size:14px}.brand{font-weight:800}.wrap{max-width:1200px;margin:24px auto;padding:0 15px}.card{background:var(--card);border-radius:12px;padding:20px;margin:15px 0;box-shadow:0 2px 10px #0000000d;border:1px solid var(--line)}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:15px}.stat{font-size:28px;font-weight:800}.muted{color:var(--muted)}.btn{display:inline-block;background:var(--accent);color:#fff;padding:9px 13px;border-radius:7px;text-decoration:none;border:0;cursor:pointer}.danger{background:#b42318}.input,select{padding:10px;width:100%;margin:5px 0 12px;border:1px solid #ccd6dd;border-radius:7px;background:#fff}.btnrow{display:flex;flex-wrap:wrap;gap:8px}table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid var(--line);text-align:left}th{background:#eef3f7}.flash{padding:10px;background:#e7f6ec;margin:10px 0;border-radius:6px}.badge{display:inline-block;padding:4px 8px;border-radius:99px;background:#eaf2f8}.error{background:#fdecec}.small{font-size:12px}@media(max-width:700px){.nav{display:block}.nav a{display:inline-block;margin:8px 8px 0 0}.tablewrap{overflow:auto}}
</style></head><body><div class="nav"><div class="brand">LPDSD — Gestion Scolaire Pro</div>{% if session.get('user_id') %}<div><a href="{{url_for('dashboard')}}">Accueil</a>{% if can('students') %}<a href="{{url_for('students')}}">Élèves</a>{% endif %}{% if can('teachers') %}<a href="{{url_for('teachers')}}">Enseignants</a>{% endif %}{% if can('payments') %}<a href="{{url_for('payments')}}">Paiements</a>{% endif %}{% if can('grades') %}<a href="{{url_for('grades')}}">Notes</a>{% endif %}{% if can('users') %}<a href="{{url_for('users')}}">Comptes</a>{% endif %}<a href="{{url_for('logout')}}">Déconnexion</a></div>{% endif %}</div><div class="wrap">{% with msgs=get_flashed_messages() %}{% for m in msgs %}<div class="flash">{{m}}</div>{% endfor %}{% endwith %}{{body|safe}}</div></body></html>'''

def can(p):
 u=current_user(); return bool(u and p in ROLES.get(u['role'],{}).get('perms',set()))
def page(body,**ctx): return render_template_string(BASE,body=render_template_string(body,**ctx),can=can)

@app.route('/',methods=['GET','POST'])
def login():
 if current_user(): return redirect(url_for('dashboard'))
 if request.method=='POST':
  c=db(); u=c.execute('SELECT * FROM users WHERE username=? AND active=1',(request.form['username'].strip(),)).fetchone(); c.close()
  if u and check_password_hash(u['password_hash'],request.form['password']):
   session.clear(); session['user_id']=u['id']; log('Connexion'); return redirect(url_for('dashboard'))
  flash('Identifiants incorrects.','error')
 return page('''<div class="card" style="max-width:430px;margin:70px auto"><h2>Connexion sécurisée</h2><p>Le Lycée Privé Daouda S Diarra</p><form method="post"><label>Nom d'utilisateur</label><input class="input" name="username" required><label>Mot de passe</label><input class="input" name="password" type="password" required><button class="btn">Se connecter</button></form><p class="small muted">Compte initial : admin / admin123. Changez-le immédiatement.</p></div>''')

@app.route('/logout')
def logout(): log('Déconnexion'); session.clear(); return redirect(url_for('login'))

@app.route('/dashboard')
@permission('dashboard')
def dashboard():
 c=db(); stats=[c.execute('SELECT COUNT(*) n FROM students').fetchone()['n'],c.execute('SELECT COUNT(*) n FROM teachers').fetchone()['n'],c.execute('SELECT COUNT(*) n FROM classes').fetchone()['n'],c.execute('SELECT COALESCE(SUM(amount),0) n FROM payments').fetchone()['n'],c.execute('SELECT COUNT(*) n FROM users WHERE active=1').fetchone()['n']]; c.close(); u=current_user()
 return page('''<h1>Tableau de bord</h1><p>Bienvenue <b>{{u['full_name'] or u['username']}}</b> — <span class="badge">{{roles[u['role']]['label']}}</span></p><div class="grid"><div class="card"><div class="stat">{{stats[0]}}</div>Élèves</div><div class="card"><div class="stat">{{stats[1]}}</div>Enseignants</div><div class="card"><div class="stat">{{stats[2]}}</div>Classes</div><div class="card"><div class="stat">{{'%.0f'|format(stats[3])}}</div>FCFA encaissés</div><div class="card"><div class="stat">{{stats[4]}}</div>Comptes actifs</div></div><div class="card"><h3>Accès de votre rôle</h3><p>{{roles[u['role']]['label']}} : {{', '.join(roles[u['role']]['perms'])}}</p></div>''',stats=stats,u=u,roles=ROLES)

@app.route('/users',methods=['GET','POST'])
@permission('users')
def users():
 c=db()
 if request.method=='POST':
  try:
   username=request.form['username'].strip(); role=request.form['role']; pwd=request.form['password']; full=request.form['full_name'].strip()
   if role not in ROLES or len(pwd)<8: raise ValueError('Mot de passe de 8 caractères minimum et rôle valide requis.')
   c.execute('INSERT INTO users(username,password_hash,role,full_name,created_at) VALUES(?,?,?,?,?)',(username,generate_password_hash(pwd),role,full,datetime.now().isoformat())); c.commit(); log('Création du compte '+username); flash('Compte créé.')
  except Exception as e: c.rollback(); flash('Erreur : '+str(e))
 rows=c.execute('SELECT id,username,role,full_name,active,created_at FROM users ORDER BY username').fetchall(); c.close()
 return page('''<h1>Comptes utilisateurs</h1><div class="card"><h3>Créer un compte</h3><form method="post" class="grid"><input class="input" name="full_name" placeholder="Nom complet" required><input class="input" name="username" placeholder="Nom d'utilisateur" required><input class="input" name="password" type="password" minlength="8" placeholder="Mot de passe (8 caractères min.)" required><select name="role">{% for k,v in roles.items() %}<option value="{{k}}">{{v.label}}</option>{% endfor %}</select><button class="btn">Créer le compte</button></form></div><div class="card tablewrap"><table><tr><th>Utilisateur</th><th>Nom</th><th>Rôle</th><th>État</th></tr>{% for x in rows %}<tr><td>{{x.username}}</td><td>{{x.full_name}}</td><td>{{roles[x.role]['label']}}</td><td>{{'Actif' if x.active else 'Désactivé'}}</td></tr>{% endfor %}</table></div>''',rows=rows,roles=ROLES)

@app.route('/users/password',methods=['GET','POST'])
def change_password():
 u=current_user()
 if not u: return redirect(url_for('login'))
 if request.method=='POST':
  old=request.form['old']; new=request.form['new'];
  if not check_password_hash(u['password_hash'],old): flash('Ancien mot de passe incorrect.')
  elif len(new)<8: flash('Le nouveau mot de passe doit avoir au moins 8 caractères.')
  else:
   c=db(); c.execute('UPDATE users SET password_hash=? WHERE id=?',(generate_password_hash(new),u['id'])); c.commit(); c.close(); flash('Mot de passe modifié.'); return redirect(url_for('dashboard'))
 return page('''<div class="card" style="max-width:500px"><h2>Changer mon mot de passe</h2><form method="post"><input class="input" name="old" type="password" placeholder="Ancien mot de passe" required><input class="input" name="new" type="password" minlength="8" placeholder="Nouveau mot de passe" required><button class="btn">Modifier</button></form></div>''')

@app.route('/backup')
@permission('backup')
def backup():
 stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); path=os.path.join(BACKUP_DIR,'lpdsd_'+stamp+'.db'); shutil.copy2(DB,path); log('Sauvegarde '+os.path.basename(path)); return send_file(path,as_attachment=True,download_name=os.path.basename(path),mimetype='application/octet-stream')

# CRUD modules inherited from v2 with role protection
@app.route('/students',methods=['GET','POST'])
@permission('students')
def students():
 c=db()
 if request.method=='POST':
  try:
   c.execute('INSERT INTO students(matricule,first_name,last_name,sex,dob,phone,class_id,guardian,guardian_phone,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(request.form['matricule'],request.form['first_name'],request.form['last_name'],request.form['sex'],request.form['dob'],request.form['phone'],request.form['class_id'],request.form['guardian'],request.form['guardian_phone'],datetime.now().isoformat())); c.commit(); log('Ajout élève '+request.form['matricule']); flash('Élève enregistré.')
  except Exception as e: c.rollback(); flash('Erreur : '+str(e))
 rows=c.execute('SELECT s.*,c.name class_name FROM students s LEFT JOIN classes c ON c.id=s.class_id ORDER BY s.last_name,s.first_name').fetchall(); classes=c.execute('SELECT * FROM classes ORDER BY name').fetchall(); c.close(); return page('''<h1>Élèves</h1><div class="card"><form method="post" class="grid"><input class="input" name="matricule" placeholder="Matricule" required><input class="input" name="first_name" placeholder="Prénom" required><input class="input" name="last_name" placeholder="Nom" required><select name="sex"><option>M</option><option>F</option></select><input class="input" name="dob" type="date"><input class="input" name="phone" placeholder="Téléphone"><select name="class_id">{% for c in classes %}<option value="{{c.id}}">{{c.name}}</option>{% endfor %}</select><input class="input" name="guardian" placeholder="Parent/Tuteur"><input class="input" name="guardian_phone" placeholder="Téléphone tuteur"><button class="btn">Enregistrer</button></form></div><div class="card tablewrap"><table><tr><th>Matricule</th><th>Nom</th><th>Classe</th><th>Téléphone</th><th>Fiche</th></tr>{% for s in rows %}<tr><td>{{s.matricule}}</td><td>{{s.last_name}} {{s.first_name}}</td><td>{{s.class_name}}</td><td>{{s.phone}}</td><td><a class="btn" href="{{url_for('student_detail',sid=s.id)}}">Ouvrir</a></td></tr>{% endfor %}</table></div>''',rows=rows,classes=classes)

@app.route('/student/<int:sid>')
def student_detail(sid):
 if not current_user(): return redirect(url_for('login'))
 c=db(); s=c.execute('SELECT s.*,c.name class_name FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=?',(sid,)).fetchone(); pays=c.execute('SELECT * FROM payments WHERE student_id=? ORDER BY paid_at DESC',(sid,)).fetchall(); c.close()
 if not s: abort(404)
 return page('''<h1>Fiche élève</h1><div class="card"><h2>{{s.last_name}} {{s.first_name}}</h2><p>Matricule : {{s.matricule}} · Classe : {{s.class_name}} · Tuteur : {{s.guardian}}</p><div class="btnrow">{% if can('payments') %}<a class="btn" href="{{url_for('payment_new',sid=s.id)}}">Ajouter paiement</a>{% endif %}{% if can('grades') %}<a class="btn" href="{{url_for('bulletin',sid=s.id)}}">Bulletin PDF</a>{% endif %}</div></div><div class="card"><h3>Paiements</h3><table><tr><th>Date</th><th>Montant</th><th>Motif</th><th>Reçu</th></tr>{% for p in pays %}<tr><td>{{p.paid_at}}</td><td>{{p.amount}} FCFA</td><td>{{p.purpose}}</td><td><a href="{{url_for('receipt',pid=p.id)}}">PDF</a></td></tr>{% endfor %}</table></div>''',s=s,pays=pays)

@app.route('/payment/new/<int:sid>',methods=['GET','POST'])
@permission('payments')
def payment_new(sid):
 c=db(); s=c.execute('SELECT * FROM students WHERE id=?',(sid,)).fetchone()
 if not s: c.close(); abort(404)
 if request.method=='POST':
  ref='PAY-'+datetime.now().strftime('%Y%m%d%H%M%S%f'); c.execute('INSERT INTO payments(student_id,amount,purpose,paid_at,reference,received_by) VALUES(?,?,?,?,?,?)',(sid,float(request.form['amount']),request.form['purpose'],datetime.now().strftime('%Y-%m-%d %H:%M'),ref,current_user()['id'])); c.commit(); pid=c.execute('SELECT last_insert_rowid()').fetchone()[0]; c.close(); log('Paiement '+ref); return redirect(url_for('receipt',pid=pid))
 c.close(); return page('''<div class="card" style="max-width:600px"><h2>Paiement — {{s.last_name}} {{s.first_name}}</h2><form method="post"><input class="input" name="amount" type="number" min="0" step="1" placeholder="Montant FCFA" required><input class="input" name="purpose" placeholder="Motif" required><button class="btn">Enregistrer et générer le reçu</button></form></div>''',s=s)

@app.route('/receipt/<int:pid>')
def receipt(pid):
 if not current_user(): return redirect(url_for('login'))
 c=db(); p=c.execute('SELECT p.*,s.first_name,s.last_name,s.matricule FROM payments p JOIN students s ON s.id=p.student_id WHERE p.id=?',(pid,)).fetchone(); c.close()
 if not p: abort(404)
 buf=io.BytesIO(); doc=SimpleDocTemplate(buf,pagesize=A4); st=getSampleStyleSheet(); story=[Paragraph('<b>LE LYCEE PRIVE DAOUD​A S DIARRA — LPDSD</b>',st['Title']),Spacer(1,20),Paragraph('REÇU DE PAIEMENT',st['Heading2']),Spacer(1,15),Paragraph(f"Référence : {p['reference']}<br/>Élève : {p['last_name']} {p['first_name']}<br/>Matricule : {p['matricule']}<br/>Motif : {p['purpose']}<br/>Montant : <b>{p['amount']:.0f} FCFA</b><br/>Date : {p['paid_at']}",st['BodyText']),Spacer(1,40),Paragraph('Signature et cachet de l’établissement',st['BodyText'])]; doc.build(story); buf.seek(0); return send_file(buf,as_attachment=False,download_name='recu.pdf',mimetype='application/pdf')

@app.route('/payments')
@permission('payments')
def payments():
 c=db(); rows=c.execute('SELECT p.*,s.first_name,s.last_name,s.matricule FROM payments p JOIN students s ON s.id=p.student_id ORDER BY p.id DESC').fetchall(); c.close(); return page('''<h1>Paiements</h1><div class="card tablewrap"><table><tr><th>Référence</th><th>Élève</th><th>Montant</th><th>Motif</th><th>Date</th><th>Reçu</th></tr>{% for p in rows %}<tr><td>{{p.reference}}</td><td>{{p.last_name}} {{p.first_name}}</td><td>{{p.amount}} FCFA</td><td>{{p.purpose}}</td><td>{{p.paid_at}}</td><td><a href="{{url_for('receipt',pid=p.id)}}">PDF</a></td></tr>{% endfor %}</table></div>''',rows=rows)

@app.route('/teachers',methods=['GET','POST'])
@permission('teachers')
def teachers():
 c=db()
 if request.method=='POST':
  try: c.execute('INSERT INTO teachers(matricule,first_name,last_name,phone,subject,class_name,created_at) VALUES(?,?,?,?,?,?,?)',(request.form['matricule'],request.form['first_name'],request.form['last_name'],request.form['phone'],request.form['subject'],request.form['class_name'],datetime.now().isoformat())); c.commit(); log('Ajout enseignant '+request.form['matricule']); flash('Enseignant enregistré.')
  except Exception as e: c.rollback(); flash('Erreur : '+str(e))
 rows=c.execute('SELECT * FROM teachers ORDER BY last_name').fetchall(); c.close(); return page('''<h1>Enseignants</h1><div class="card"><form method="post" class="grid"><input class="input" name="matricule" placeholder="Matricule" required><input class="input" name="first_name" placeholder="Prénom" required><input class="input" name="last_name" placeholder="Nom" required><input class="input" name="phone" placeholder="Téléphone"><input class="input" name="subject" placeholder="Matière"><input class="input" name="class_name" placeholder="Classe"><button class="btn">Enregistrer</button></form></div><div class="card tablewrap"><table><tr><th>Matricule</th><th>Nom</th><th>Matière</th><th>Classe</th></tr>{% for t in rows %}<tr><td>{{t.matricule}}</td><td>{{t.last_name}} {{t.first_name}}</td><td>{{t.subject}}</td><td>{{t.class_name}}</td></tr>{% endfor %}</table></div>''',rows=rows)

@app.route('/grades',methods=['GET','POST'])
@permission('grades')
def grades():
 c=db()
 if request.method=='POST':
  c.execute('INSERT INTO grades(student_id,subject,term,score,coefficient,entered_by) VALUES(?,?,?,?,?,?)',(request.form['student_id'],request.form['subject'],request.form['term'],float(request.form['score']),float(request.form['coefficient']),current_user()['id'])); c.commit(); log('Saisie note')
 students=c.execute('SELECT * FROM students ORDER BY last_name').fetchall(); rows=c.execute('SELECT g.*,s.first_name,s.last_name FROM grades g JOIN students s ON s.id=g.student_id ORDER BY g.id DESC').fetchall(); c.close(); return page('''<h1>Notes</h1><div class="card"><form method="post" class="grid"><select name="student_id">{% for s in students %}<option value="{{s.id}}">{{s.last_name}} {{s.first_name}} — {{s.matricule}}</option>{% endfor %}</select><input class="input" name="subject" placeholder="Matière" required><select name="term"><option>Trimestre 1</option><option>Trimestre 2</option><option>Trimestre 3</option></select><input class="input" name="score" type="number" min="0" max="20" step="0.01" placeholder="Note /20" required><input class="input" name="coefficient" type="number" min="0.5" step="0.5" value="1"><button class="btn">Enregistrer</button></form></div><div class="card tablewrap"><table><tr><th>Élève</th><th>Matière</th><th>Période</th><th>Note</th><th>Coef.</th></tr>{% for g in rows %}<tr><td>{{g.last_name}} {{g.first_name}}</td><td>{{g.subject}}</td><td>{{g.term}}</td><td>{{g.score}}</td><td>{{g.coefficient}}</td></tr>{% endfor %}</table></div>''',students=students,rows=rows)

@app.route('/bulletin/<int:sid>')
@permission('grades')
def bulletin(sid):
 c=db(); s=c.execute('SELECT s.*,c.name class_name FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=?',(sid,)).fetchone(); gs=c.execute('SELECT subject,term,score,coefficient FROM grades WHERE student_id=? ORDER BY term,subject',(sid,)).fetchall(); c.close()
 if not s: abort(404)
 buf=io.BytesIO(); doc=SimpleDocTemplate(buf,pagesize=A4); st=getSampleStyleSheet(); story=[Paragraph('LE LYCEE PRIVE DAOUD​A S DIARRA — LPDSD',st['Title']),Paragraph('BULLETIN SCOLAIRE',st['Heading2']),Spacer(1,10),Paragraph(f"Élève : {s['last_name']} {s['first_name']}<br/>Matricule : {s['matricule']}<br/>Classe : {s['class_name']}",st['BodyText']),Spacer(1,15)]; data=[['Matière','Période','Note /20','Coef.']]+[[g['subject'],g['term'],str(g['score']),str(g['coefficient'])] for g in gs]; t=Table(data,colWidths=[180,120,90,70]); t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#0b3558')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),.5,colors.grey),('PADDING',(0,0),(-1,-1),7)])); story += [t,Spacer(1,20),Paragraph('Observation / Décision du conseil de classe : ________________________________',st['BodyText']),Spacer(1,35),Paragraph('Le Proviseur',st['BodyText'])]; doc.build(story); buf.seek(0); return send_file(buf,as_attachment=False,download_name='bulletin.pdf',mimetype='application/pdf')

@app.errorhandler(403)
def forbidden(e): return page('<div class="card"><h2>Accès refusé</h2><p>Votre rôle ne vous autorise pas à accéder à ce module.</p></div>'),403
if __name__=='__main__': app.run(host='127.0.0.1',port=5000,debug=False)
